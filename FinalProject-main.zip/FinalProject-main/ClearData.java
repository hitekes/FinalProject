public class ClearData {
    private static void clearData() {
    cars.clear();
    System.out.println("Все данные очищены.");
    }
}
