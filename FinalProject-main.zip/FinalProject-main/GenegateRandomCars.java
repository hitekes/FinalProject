public class GenegateRandomCars {
     System.out.println("Сгенерировано " + count + " случайных машин.");
}
